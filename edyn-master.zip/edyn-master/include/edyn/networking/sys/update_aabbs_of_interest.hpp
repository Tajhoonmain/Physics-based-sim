#ifndef EDYN_NETWORKING_UPDATE_AABBS_OF_INTEREST_HPP
#define EDYN_NETWORKING_UPDATE_AABBS_OF_INTEREST_HPP

#include <entt/entity/fwd.hpp>

namespace edyn {

void update_aabbs_of_interest(entt::registry &);

}

#endif // EDYN_NETWORKING_UPDATE_AABBS_OF_INTEREST_HPP
