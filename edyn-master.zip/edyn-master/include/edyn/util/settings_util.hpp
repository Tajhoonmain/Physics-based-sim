#ifndef EDYN_UTIL_SETTINGS_UTIL_HPP
#define EDYN_UTIL_SETTINGS_UTIL_HPP

#include <entt/entity/fwd.hpp>

namespace edyn {

void refresh_settings(entt::registry &);

}

#endif // EDYN_UTIL_SETTINGS_UTIL_HPP
